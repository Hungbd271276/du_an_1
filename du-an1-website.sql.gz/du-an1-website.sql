-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2020 at 04:35 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `du-an1-website`
--

-- --------------------------------------------------------

--
-- Table structure for table `bai_viet`
--

CREATE TABLE `bai_viet` (
  `stt` int(11) NOT NULL,
  `ten_bai_viet` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chi_tiet` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `bai_viet`
--

INSERT INTO `bai_viet` (`stt`, `ten_bai_viet`, `images`, `chi_tiet`) VALUES
(2, 'Kiểu tóc UnderCut', '/upload/toc1.jpg', 'Kiểu tóc undercut có đặc điểm là phần tóc 2 bên được cắt tỉa ngắn, phần tóc phía sau sẽ được cắt cao, còn riêng phần tóc phía trước sẽ được cắt ngắn, dài hoặc tạo kiểu tùy vào sở thích, gương mặt của mỗi người. Chính vì vậy, kiểu tóc này có nhiều biến thể khác nhau. Dù gương mặt của bạn là tròn, dài hay vuông thì kiểu tóc undercut vẫn có thể giúp bạn che đi khuyết điểm để làm tăng lên vẻ nam tính, cuốn hút mọi ánh nhìn. '),
(3, 'Kiểu tóc minical', '/upload/toc2.jpg', 'Năm 2018 – 2020 rộ lên xu hướng kiểu tóc nam Mohican. Mặc dù cái tên này không phải là mới xuất hiện, nếu không muốn nói là đã có từ lâu đời, tuy nhiên năm 2020 Mohican lại có sự thay đổi ngoạn mục khi được biến tấu thành một phong cách tóc nam ngắn hoàn toàn mới, hiện đại, trẻ trung, gọn gàng nam tính nhưng vẫn cực kỳ thời trang.'),
(4, 'Kiểu tóc nam ngắn Hàn Quốc Textured crop', '/upload/toc-nam-ngan-40.jpg', 'Là một phong cách được phổ biến rộng rãi trong các cửa hàng cắt tóc trên toàn thế giới. Nhiều người coi nó là một cái nhìn điển hình của người Anh nên không có gì ngạc nhiên khi sự hồi sinh trong phong cách này lần đầu tiên được thấy ở các tiệm cắt tại Việt Nam. Kiểu tóc textured crop ngắn là một xu hướng tóc nam đã làm mưa làm gió trong những năm gần đây.\r\nĐến nay kiểu tóc nam ngắn này vẫn đang là một xu hướng được rất nhiều anh em ưa chuộng trong năm 2018, vì sự mới lạ và vẻ đẹp mà nó mang lại. Các chàng trai sành điệu cá tính luôn làm mới bản thân bằng những kiểu tóc mới lạ độc đáo phù hợp với xu hướng thịnh hành. Tóc texture ngắn giúp các chàng trai thoải mái hơn trong những ngày hè nắng nóng.'),
(5, 'Kiểu tóc xoăn ngắn', '/upload/toc-nam-ngan-2.jpg', 'Tóc xoăn ngắn nam Hàn Quốc đẹp hợp mọi khuôn mặt của các chàng có vẻ ngoài sành điệu và cá tính, thích hợp hơn cả khi được áp dụng vào ngày đi tiệc hay đi làm. Tóc xoăn chính là một trong những style tóc vô cùng đẹp mắt mang thương hiệu đúng chuẩn xứ Hàn, đặc biệt là với những người sở hữu mái tóc ngắn chưa có điểm nhấn tinh tế.\r\nĐừng ngần ngại thay đổi phong cách của mình, nếu bạn đang có một mái tóc ngắn thì một kiểu tóc xoăn sẽ khiến bạn như lột xác và đưa bạn đến với một phong cách hoàn toàn mới đầy trẻ trung và năng động.'),
(6, 'Kiểu tóc Pompadour ', '/upload/kieu-toc-nam-dep-2019-8.jpg', 'Pompadour là kiểu tóc khá quen thuộc với anh em chơi sáp, rộ lên từ khoảng 5 năm trở lại đây. Pompadour là kiểu tóc Undercut vuốt ngược, với điểm nổi bật là phần đỉnh được uốn tạo phồng max volume.\r\n\r\nĐộ phồng (volume) của Pomp phụ thuộc vào nhiều yếu tố như: cách sấy, dùng Pre-styling nào, dùng loại sáp khác nhau, chất tóc và kinh nghiệm tạo kiểu tóc nam cũng là yếu tố cực kỳ quan trọng để quyết định nên một mái tóc Pompadour đẹp. Pompadour, cũng như một số kiểu Undercut vuốt dựng cũng là giải pháp “ăn gian chiều cao” của không ít anh em đấy!'),
(7, 'Kiểu tóc Buzz Cut (đầu cua ngắn)', '/upload/toc-nam-ngan-46.jpg', 'Chắc chắn bất cứ chàng trai nào cũng đã từng nghe về kiểu tóc này. Đó cũng là điều dễ hiểu, vì kiể tóc này đã tồn tại và phổ biến từ rất nhiều năm về trước không chỉ ở Việt Nam, mà còn ở nhiều nước thế giới. Về nguồn gốc cũng như quá trình phát triển, Buzz Cut có thể nói là đàn ảnh của các kiểu tóc nam ngắn Undercut, kiểu tóc short Pompadour hay kiểu tóc side part.\r\nĐây là kiểu tóc cực kì thích hợp cho các chàng vào mùa Hè sắp tới đấy! Vì đây là một kiểu tóc cực đơn giản nhưng cũng có cá tính cực mạnh nên các bạn phải chắc chắn một chút trước khi “xuống tóc” nhé.'),
(8, 'Kiểu tóc nam đẹp 7/3', '/upload/TOC-NAM-NGAN-DEP-3.jpg', 'Các kiểu tóc nam đẹp 7/3 mang hình ảnh đẹp và ngắn gọn với phong cách tự nhiên, cá tính và kiểu cách không chỉ giúp các chàng trai thêm phần tự tin, mà còn giúp làm nổi lên sự bảnh bao của khuôn mặt phái mạnh.\r\nTóc nam đẹp kiểu 7/3 có thể hợp với nhiều bạn nam, với khuôn mặt góc cạnh và gọn gàng tùy từng người. Nếu bạn thích cá tính thêm một chút, thì hoàn toàn có thể nhuộm một vài tone màu cá tính để tăng thêm sự cuốn hút.'),
(9, 'kiểu tóc nam ngắn đẹp vuốt ngược', '/upload/TOC-NAM-NGAN-DEP-19.jpg', 'Kiểu đầu vuốt ngược không chỉ giúp làm lộ khuôn mặt góc cạnh, nam tính mà còn giúp tăng thêm được phần nào chiều cao của các bạn nam, nếu thường xuyên dùng gel, sáp, thì đây sẽ là một kiểu tóc cực kì lý tưởng với bạn đấy.');

-- --------------------------------------------------------

--
-- Table structure for table `dich_vu`
--

CREATE TABLE `dich_vu` (
  `ma_dv` int(11) NOT NULL,
  `ten_dv` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gia` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `chi_tiet` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dich_vu`
--

INSERT INTO `dich_vu` (`ma_dv`, `ten_dv`, `gia`, `images`, `chi_tiet`) VALUES
(8, 'Curling Hair', '300.000 vnđ', '/upload/dich-vu-2.jpg', 'Tư vấn, xả tóc, uốn tóc, cắt tóc, gội đầu & Massage, cạo râu, tạo kiểu tóc bằng các sản phẩm Mane-Man Australia'),
(9, 'Diamond Cut	', '120.000 vnđ', '/upload/dich-vu-1.jpg', 'Tư vấn, xả tóc, cắt tóc, gội đầu & Massage, lột mụn, cạo râu, tạo kiểu tóc bằng các sản phẩm Mane-Man Australia | Miễn phí tất cả đồ uống'),
(10, 'Bronze Cut	', '300.000 vnđ', '/upload/dich-vu-7.jpg', 'Tư vấn, cắt tóc, cạo râu, tạo kiểu tóc bằng các sản phẩm Mane-Man Australia.Miễn phí tất cả đồ uống và coffe'),
(11, 'Silver Cut	', '80.000 vnđ', '/upload/dich-vu-6.jpg', 'Tư vấn, xả tóc, cắt tóc, cạo râu, tạo kiểu tóc bằng các sản phẩm Mane-Man Australia.Miễn phí tất cả đồ uống và coffe'),
(12, 'Kids Cut', '30.000 vnđ', '/upload/dich-vu-5.jpg', 'Tư vấn, cắt tóc, tạo kiểu tóc bằng các sản phẩm Mane-Man Australia.Miễn phí tất cả đồ uống và coffe'),
(13, 'Dye Hair	', '300.000 vnđ', '/upload/dich-vu-4.jpg', 'Tư vấn, xả tóc, nhuộm tóc, cắt tóc, gội đầu & Massage, cạo râu, tạo kiểu tóc bằng các sản phẩm Mane-Man Australia'),
(14, 'Golden Cut	', '100.000 vnđ', '/upload/dich-vu-3.jpg', 'Tư vấn, xả tóc, cắt tóc, gội đầu & Massage, cạo râu, tạo kiểu tóc bằng các sản phẩm Mane-Man Australia | Miễn phí Coffee'),
(15, 'Kids Diamond Cut', '80.000 vnđ', '/upload/dich-vu-3.jpg', 'Tư vấn, xả tóc, cắt tóc, gội đầu & Massage, tạo kiểu tóc bằng các sản phẩm Mane-Man Australia | Miễn phí tất cả đồ uống'),
(16, 'Removal Hair	', '100.000 vnđ', '/upload/dich-vu-1.jpg', 'Tẩy tóc bằng những dòng sản phẩm cao cấp chất lượng đến từ Hàn Quốc.Miễn phí tất cả đồ uống		\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `gioi_thieu`
--

CREATE TABLE `gioi_thieu` (
  `id_bv` int(11) NOT NULL,
  `tieu_de` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `content` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `gioi_thieu`
--

INSERT INTO `gioi_thieu` (`id_bv`, `tieu_de`, `images`, `content`) VALUES
(1, 'I. Giới thiệu', '/upload/toc.jpg', 'Cái tên Barber shop được sử dụng rất nhiều ở châu Âu, đặc biệt là các quốc gia như Mỹ, Anh và Hà Lan, điển hình như: Schorem, Fellow Barber và Ruffians Barber. Không gian barber thường được bày biện rất nhiều những tranh ảnh mang phong cách Metal, cùng với đó là ghế cắt Barber Chair cao cấp, gương lớn to bản, giường gội kiểu Tây Âu,…v..v…Trông có vẻ khá là đầy đủ rồi đó nhỉ? Cái tên Barber shop được sử dụng rất nhiều ở châu Âu, đặc biệt là các quốc gia như Mỹ, Anh và Hà Lan, điển hình như: Schorem, Fellow Barber và Ruffians Barber. Không gian barber thường được bày biện rất nhiều những tranh ảnh mang phong cách Metal, cùng với đó là ghế cắt Barber Chair cao cấp, gương lớn to bản, giường gội kiểu Tây Âu,…v..v…Trông có vẻ khá là đầy đủ rồi đó nhỉ? Cái tên Barber shop được sử dụng rất nhiều ở châu Âu, đặc biệt là các quốc gia như Mỹ, Anh và Hà Lan, điển hình như: Schorem, Fellow Barber và Ruffians Barber. Không gian barber thường được bày biện rất nhiều những tranh ảnh mang phong cách Metal, cùng với đó là ghế cắt Barber Chair cao cấp, gương lớn to bản, giường gội kiểu Tây Âu,…v..v…Trông có vẻ khá là đầy đủ rồi đó nhỉ?'),
(2, 'II. Sứ mệnh', '/upload/unnamed.png', 'Kinh doanh sản phẩm thuộc các thương hiệu nổi tiếng về Tóc hàng đầu trên thế giới, mang đến cho hệ thống Salon chuyên nghiệp tại Việt Nam những sản phẩm chất lượng với chính sách giá tốt nhất, góp phần kiến tạo thành công chung trong lĩnh vực chăm sóc, làm đẹp Tóc. <br>\r\n\r\nKhông dừng lại ở đó, BTA Hair Company ra đời với sứ mệnh trở thành đối tác tin cậy và toàn diện trong mọi mối quan hệ với Salon, nhà phân phối cũng như từng khách hàng. BTA cũng chính là ngôi nhà chung, nơi gắn kết những con người nhiệt huyết, sống và làm việc với tinh thần trách nhiệm cao, mang đến những giá trị thiết thực.<br>\r\nTẦM NHÌN<br>\r\n\r\nBarBer luôn nỗ lực không ngừng để trở thành 1 trong 10 đơn vị top đầu trong lĩnh vực  ngành tóc vào năm 2020 với:<br>\r\n\r\n+ Hệ thống Salon đạt 3000 trải dài từ Bắc vào Nam.<br>\r\n\r\n+ Hệ thống nhà phân phối tăng lên 15 - 20% mỗi năm.<br>\r\n\r\n+ Data khách hàng lẻ ngày càng lớn <br>\r\n\r\n+ Đội ngũ nhân viên ngày càng mở rộng, gắn kết hơn');

-- --------------------------------------------------------

--
-- Table structure for table `khach_hang`
--

CREATE TABLE `khach_hang` (
  `id` int(11) NOT NULL,
  `ten_khach_hang` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SDT` char(20) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `khach_hang`
--

INSERT INTO `khach_hang` (`id`, `ten_khach_hang`, `SDT`) VALUES
(1, 'Bùi Đức Hùng', '0963484762'),
(3, 'Nguyễn Văn B', '00443434343');

-- --------------------------------------------------------

--
-- Table structure for table `lich_hen`
--

CREATE TABLE `lich_hen` (
  `stt` int(11) NOT NULL,
  `nhan_vien` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten_kh` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sdt_kh` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `gio_hen` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ngay_hen` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dich_vu` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `lich_hen`
--

INSERT INTO `lich_hen` (`stt`, `nhan_vien`, `ten_kh`, `sdt_kh`, `gio_hen`, `ngay_hen`, `dich_vu`) VALUES
(22, 'Bùi Đức Hùng', 'Đỗ Mạnh Lâm', '0963484762', '2020-12-05', '8h-11h sáng', 'dịch vụ cắt tóc'),
(23, 'Bùi Đức B', 'Nguyễn Thi A', '00443434343', '2020-12-06', '2h-4h30 chiều', 'Golden Cut	');

-- --------------------------------------------------------

--
-- Table structure for table `nhan_vien`
--

CREATE TABLE `nhan_vien` (
  `id_nv` int(11) NOT NULL,
  `username` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `passwd` char(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ten_nv` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `SDT` char(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` char(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `images` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nhan_vien`
--

INSERT INTO `nhan_vien` (`id_nv`, `username`, `passwd`, `ten_nv`, `SDT`, `email`, `images`) VALUES
(14, 'hungbdph10926', '$2y$10$lKt51.DFI0yUmJsBp7./VukNeJFsgMuTCZmTBAD/.Lv8zHR0p7XqW', 'Bùi Thanh hùng', '00443434343', 'hb4654356@gmail.com', ''),
(15, 'admin2', '$2y$10$h2eWadsvJ4BESm5dXsTjZ.QCDSFcNkjhBvy5.cz29n0afnbN4SpEG', 'Bùi Đức B', '00443434343', 'admin@gmail.com', ''),
(16, 'admin', '$2y$10$CkGCl9vdmnHddCetpjdO3.qR0zpmhwu4ScMC7zbWN4Pr3evEGc3pS', 'Bùi Đức Hùng', '0963484761', 'hungbdph10926@fpt.edu.vn', '');

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE `slide` (
  `ma_slide` int(11) NOT NULL,
  `ten_slide` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ngay_dang` char(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `anh_slide` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`ma_slide`, `ten_slide`, `ngay_dang`, `anh_slide`) VALUES
(3, 'slide baber2', '27/11/2020', '/upload/124577969_1016883622113420_2799405275517977553_n.png'),
(5, 'slide baber', '10-10-2020', '/upload/124574112_835577570541043_2682567266386789800_n.png'),
(6, 'slide baber 3', '10-10-2020', '/upload/124419495_386334379153943_2906245739108076202_n.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bai_viet`
--
ALTER TABLE `bai_viet`
  ADD PRIMARY KEY (`stt`);

--
-- Indexes for table `dich_vu`
--
ALTER TABLE `dich_vu`
  ADD PRIMARY KEY (`ma_dv`);

--
-- Indexes for table `gioi_thieu`
--
ALTER TABLE `gioi_thieu`
  ADD PRIMARY KEY (`id_bv`);

--
-- Indexes for table `khach_hang`
--
ALTER TABLE `khach_hang`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `lich_hen`
--
ALTER TABLE `lich_hen`
  ADD PRIMARY KEY (`stt`);

--
-- Indexes for table `nhan_vien`
--
ALTER TABLE `nhan_vien`
  ADD PRIMARY KEY (`id_nv`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`ma_slide`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `bai_viet`
--
ALTER TABLE `bai_viet`
  MODIFY `stt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `dich_vu`
--
ALTER TABLE `dich_vu`
  MODIFY `ma_dv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `gioi_thieu`
--
ALTER TABLE `gioi_thieu`
  MODIFY `id_bv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `khach_hang`
--
ALTER TABLE `khach_hang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `lich_hen`
--
ALTER TABLE `lich_hen`
  MODIFY `stt` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `nhan_vien`
--
ALTER TABLE `nhan_vien`
  MODIFY `id_nv` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `ma_slide` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
